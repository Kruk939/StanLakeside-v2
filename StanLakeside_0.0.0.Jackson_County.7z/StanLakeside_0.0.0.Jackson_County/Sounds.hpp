class CfgSounds
{
	class unlockCar
	{
		name = "unlockCar";
		sound[] = {"\Sounds\unlockCar.ogg", 2, 1};
		titles[] = {1, ""};
	};
	class handcuffs
	{
		name = "handcuffs";
		sound[] = {"\Sounds\handcuffs.ogg", 2, 1};
		titles[] = {1, ""};
	};
	#include "Functions\modules\CONFIG\moduleSounds.hpp"
};