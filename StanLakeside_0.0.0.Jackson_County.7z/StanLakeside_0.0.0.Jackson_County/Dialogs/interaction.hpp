class interaction
{
	idd = 1014;
	class controls 
	{








		class RscButton_1600: RscButton
		{
			idc = 1600;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.4 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [0] call Client_fnc_interactionAction;
		};
		class RscButton_1601: RscButton
		{
			idc = 1601;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.44 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [1] call Client_fnc_interactionAction;
		};
		class RscButton_1602: RscButton
		{
			idc = 1602;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.48 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [2] call Client_fnc_interactionAction;
		};
		class RscButton_1603: RscButton
		{
			idc = 1603;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.52 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [3] call Client_fnc_interactionAction;
		};
		class RscButton_1604: RscButton
		{
			idc = 1604;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.56 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [4] call Client_fnc_interactionAction;
		};
		class RscButton_1605: RscButton
		{
			idc = 1605;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.6 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [5] call Client_fnc_interactionAction;
		};
		class RscButton_1606: RscButton
		{
			idc = 1606;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.64 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [6] call Client_fnc_interactionAction;
		};
		class RscButton_1607: RscButton
		{
			idc = 1607;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.68 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [7] call Client_fnc_interactionAction;
		};
		class RscButton_1608: RscButton
		{
			idc = 1608;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.72 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [8] call Client_fnc_interactionAction;
		};
		class RscButton_1609: RscButton
		{
			idc = 1609;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.4 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [9] call Client_fnc_interactionAction;
		};
		class RscButton_1610: RscButton
		{
			idc = 1610;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.44 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [10] call Client_fnc_interactionAction;
		};
		class RscButton_1611: RscButton
		{
			idc = 1611;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.48 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [11] call Client_fnc_interactionAction;
		};
		class RscButton_1612: RscButton
		{
			idc = 1612;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.52 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [12] call Client_fnc_interactionAction;
		};
		class RscButton_1613: RscButton
		{
			idc = 1613;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.56 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			
			colorBackground[] = {0,0,0.2,0.9};
			action = [13] call Client_fnc_interactionAction;
		};
		class RscButton_1614: RscButton
		{
			idc = 1614;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.6 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [14] call Client_fnc_interactionAction;
		};
		class RscButton_1615: RscButton
		{
			idc = 1615;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.64 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [15] call Client_fnc_interactionAction;
		};
		class RscButton_1616: RscButton
		{
			idc = 1616;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.68 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [16] call Client_fnc_interactionAction;
		};
		class RscButton_1617: RscButton
		{
			idc = 1617;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.72 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [17] call Client_fnc_interactionAction;
		};


		class RscButton_1618: RscButton
		{
			idc = 1618;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.72 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [18] call Client_fnc_interactionAction;
		};

		class RscButton_1619: RscButton
		{
			idc = 1619;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.4 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [19] call Client_fnc_interactionAction;
		};
		class RscButton_1620: RscButton
		{
			idc = 1620;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.44 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [20] call Client_fnc_interactionAction;
		};
		class RscButton_1621: RscButton
		{
			idc = 1621;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.48 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [21] call Client_fnc_interactionAction;
		};
		class RscButton_1622: RscButton
		{
			idc = 1622;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.52 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [22] call Client_fnc_interactionAction;
		};
		class RscButton_1623: RscButton
		{
			idc = 1623;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.56 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [23] call Client_fnc_interactionAction;
		};
		class RscButton_1624: RscButton
		{
			idc = 1624;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.6 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [24] call Client_fnc_interactionAction;
		};
		class RscButton_1625: RscButton
		{
			idc = 1625;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.64 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [25] call Client_fnc_interactionAction;
		};
		class RscButton_1626: RscButton
		{
			idc = 1626;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.68 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0,0.2,0.9};
			action = [26] call Client_fnc_interactionAction;
		};


























		class RscButton_16001: RscButton
		{
			idc = 16001;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.4 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [0] call Client_fnc_interactionAction;
		};
		class RscButton_16011: RscButton
		{
			idc = 16011;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.44 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [1] call Client_fnc_interactionAction;
		};
		class RscButton_16021: RscButton
		{
			idc = 16021;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.48 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [2] call Client_fnc_interactionAction;
		};
		class RscButton_16031: RscButton
		{
			idc = 16031;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.52 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [3] call Client_fnc_interactionAction;
		};
		class RscButton_16041: RscButton
		{
			idc = 16041;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.56 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [4] call Client_fnc_interactionAction;
		};
		class RscButton_16051: RscButton
		{
			idc = 16051;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.6 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [5] call Client_fnc_interactionAction;
		};
		class RscButton_16061: RscButton
		{
			idc = 16061;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.64 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [6] call Client_fnc_interactionAction;
		};
		class RscButton_16071: RscButton
		{
			idc = 16071;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.68 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [7] call Client_fnc_interactionAction;
		};
		class RscButton_16081: RscButton
		{
			idc = 16081;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.72 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [8] call Client_fnc_interactionAction;
		};
		class RscButton_16091: RscButton
		{
			idc = 16091;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.4 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [9] call Client_fnc_interactionAction;
		};
		class RscButton_16101: RscButton
		{
			idc = 16101;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.44 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [10] call Client_fnc_interactionAction;
		};
		class RscButton_16111: RscButton
		{
			idc = 16111;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.48 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [11] call Client_fnc_interactionAction;
		};
		class RscButton_16121: RscButton
		{
			idc = 16121;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.52 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [12] call Client_fnc_interactionAction;
		};
		class RscButton_16131: RscButton
		{
			idc = 16131;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.56 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			
			colorBackground[] = {0, 0, 0, 0.9};
			action = [13] call Client_fnc_interactionAction;
		};
		class RscButton_16141: RscButton
		{
			idc = 16141;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.6 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [14] call Client_fnc_interactionAction;
		};
		class RscButton_16151: RscButton
		{
			idc = 16151;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.64 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [15] call Client_fnc_interactionAction;
		};
		class RscButton_16161: RscButton
		{
			idc = 16161;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.68 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [16] call Client_fnc_interactionAction;
		};
		class RscButton_16171: RscButton
		{
			idc = 16171;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.72 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [17] call Client_fnc_interactionAction;
		};


		class RscButton_16181: RscButton
		{
			idc = 16181;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.72 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [18] call Client_fnc_interactionAction;
		};

		class RscButton_16191: RscButton
		{
			idc = 16191;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.4 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [19] call Client_fnc_interactionAction;
		};
		class RscButton_16201: RscButton
		{
			idc = 16201;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.44 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [20] call Client_fnc_interactionAction;
		};
		class RscButton_16211: RscButton
		{
			idc = 16211;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.48 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [21] call Client_fnc_interactionAction;
		};
		class RscButton_16221: RscButton
		{
			idc = 16221;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.52 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [22] call Client_fnc_interactionAction;
		};
		class RscButton_16231: RscButton
		{
			idc = 16231;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.56 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [23] call Client_fnc_interactionAction;
		};
		class RscButton_16241: RscButton
		{
			idc = 16241;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.6 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [24] call Client_fnc_interactionAction;
		};
		class RscButton_16251: RscButton
		{
			idc = 16251;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.64 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [25] call Client_fnc_interactionAction;
		};
		class RscButton_16261: RscButton
		{
			idc = 16261;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.68 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0, 0, 0, 0.9};
			action = [26] call Client_fnc_interactionAction;
		};








		
		class RscButton_16002: RscButton
		{
			idc = 16002;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.4 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [0] call Client_fnc_interactionAction;
		};
		class RscButton_16012: RscButton
		{
			idc = 16012;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.44 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [1] call Client_fnc_interactionAction;
		};
		class RscButton_16022: RscButton
		{
			idc = 16022;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.48 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [2] call Client_fnc_interactionAction;
		};
		class RscButton_16032: RscButton
		{
			idc = 16032;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.52 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [3] call Client_fnc_interactionAction;
		};
		class RscButton_16042: RscButton
		{
			idc = 16042;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.56 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [4] call Client_fnc_interactionAction;
		};
		class RscButton_16052: RscButton
		{
			idc = 16052;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.6 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [5] call Client_fnc_interactionAction;
		};
		class RscButton_16062: RscButton
		{
			idc = 16062;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.64 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [6] call Client_fnc_interactionAction;
		};
		class RscButton_16072: RscButton
		{
			idc = 16072;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.68 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [7] call Client_fnc_interactionAction;
		};
		class RscButton_16082: RscButton
		{
			idc = 16082;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.72 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [8] call Client_fnc_interactionAction;
		};
		class RscButton_16092: RscButton
		{
			idc = 16092;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.4 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [9] call Client_fnc_interactionAction;
		};
		class RscButton_16102: RscButton
		{
			idc = 16102;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.44 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [10] call Client_fnc_interactionAction;
		};
		class RscButton_16112: RscButton
		{
			idc = 16112;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.48 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [11] call Client_fnc_interactionAction;
		};
		class RscButton_16122: RscButton
		{
			idc = 16122;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.52 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [12] call Client_fnc_interactionAction;
		};
		class RscButton_16132: RscButton
		{
			idc = 16132;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.56 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			
			colorBackground[] = {0,0.15,0,0.9};
			action = [13] call Client_fnc_interactionAction;
		};
		class RscButton_16142: RscButton
		{
			idc = 16142;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.6 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [14] call Client_fnc_interactionAction;
		};
		class RscButton_16152: RscButton
		{
			idc = 16152;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.64 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [15] call Client_fnc_interactionAction;
		};
		class RscButton_16162: RscButton
		{
			idc = 16162;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.68 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [16] call Client_fnc_interactionAction;
		};
		class RscButton_16172: RscButton
		{
			idc = 16172;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.72 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [17] call Client_fnc_interactionAction;
		};


		class RscButton_16182: RscButton
		{
			idc = 16182;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.72 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [18] call Client_fnc_interactionAction;
		};

		class RscButton_16192: RscButton
		{
			idc = 16192;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.4 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [19] call Client_fnc_interactionAction;
		};
		class RscButton_16202: RscButton
		{
			idc = 16202;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.44 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [20] call Client_fnc_interactionAction;
		};
		class RscButton_16212: RscButton
		{
			idc = 16212;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.48 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [21] call Client_fnc_interactionAction;
		};
		class RscButton_16222: RscButton
		{
			idc = 16222;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.52 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [22] call Client_fnc_interactionAction;
		};
		class RscButton_16232: RscButton
		{
			idc = 16232;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.56 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [23] call Client_fnc_interactionAction;
		};
		class RscButton_16242: RscButton
		{
			idc = 16242;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.6 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [24] call Client_fnc_interactionAction;
		};
		class RscButton_16252: RscButton
		{
			idc = 16252;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.64 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [25] call Client_fnc_interactionAction;
		};
		class RscButton_16262: RscButton
		{
			idc = 16262;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.68 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0,0.15,0,0.9};
			action = [26] call Client_fnc_interactionAction;
		};










		
		class RscButton_16003: RscButton
		{
			idc = 16003;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.4 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [0] call Client_fnc_interactionAction;
		};
		class RscButton_16013: RscButton
		{
			idc = 16013;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.44 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [1] call Client_fnc_interactionAction;
		};
		class RscButton_16023: RscButton
		{
			idc = 16023;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.48 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [2] call Client_fnc_interactionAction;
		};
		class RscButton_16033: RscButton
		{
			idc = 16033;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.52 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [3] call Client_fnc_interactionAction;
		};
		class RscButton_16043: RscButton
		{
			idc = 16043;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.56 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [4] call Client_fnc_interactionAction;
		};
		class RscButton_16053: RscButton
		{
			idc = 16053;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.6 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [5] call Client_fnc_interactionAction;
		};
		class RscButton_16063: RscButton
		{
			idc = 16063;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.64 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [6] call Client_fnc_interactionAction;
		};
		class RscButton_16073: RscButton
		{
			idc = 16073;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.68 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [7] call Client_fnc_interactionAction;
		};
		class RscButton_16083: RscButton
		{
			idc = 16083;
			x = 0.53125 * safezoneW + safezoneX;
			y = 0.72 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [8] call Client_fnc_interactionAction;
		};
		class RscButton_16093: RscButton
		{
			idc = 16093;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.4 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [9] call Client_fnc_interactionAction;
		};
		class RscButton_16103: RscButton
		{
			idc = 16103;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.44 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [10] call Client_fnc_interactionAction;
		};
		class RscButton_16113: RscButton
		{
			idc = 16113;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.48 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [11] call Client_fnc_interactionAction;
		};
		class RscButton_16123: RscButton
		{
			idc = 16123;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.52 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [12] call Client_fnc_interactionAction;
		};
		class RscButton_16133: RscButton
		{
			idc = 16133;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.56 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			
			colorBackground[] = {0.5,0,0,0.9};
			action = [13] call Client_fnc_interactionAction;
		};
		class RscButton_16143: RscButton
		{
			idc = 16143;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.6 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [14] call Client_fnc_interactionAction;
		};
		class RscButton_16153: RscButton
		{
			idc = 16153;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.64 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [15] call Client_fnc_interactionAction;
		};
		class RscButton_16163: RscButton
		{
			idc = 16163;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.68 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [16] call Client_fnc_interactionAction;
		};
		class RscButton_16173: RscButton
		{
			idc = 16173;
			x = 0.64125 * safezoneW + safezoneX;
			y = 0.72 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [17] call Client_fnc_interactionAction;
		};


		class RscButton_16183: RscButton
		{
			idc = 16183;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.72 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [18] call Client_fnc_interactionAction;
		};

		class RscButton_16193: RscButton
		{
			idc = 16193;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.4 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [19] call Client_fnc_interactionAction;
		};
		class RscButton_16203: RscButton
		{
			idc = 16203;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.44 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [20] call Client_fnc_interactionAction;
		};
		class RscButton_16213: RscButton
		{
			idc = 16213;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.48 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [21] call Client_fnc_interactionAction;
		};
		class RscButton_16223: RscButton
		{
			idc = 16223;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.52 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [22] call Client_fnc_interactionAction;
		};
		class RscButton_16233: RscButton
		{
			idc = 16233;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.56 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [23] call Client_fnc_interactionAction;
		};
		class RscButton_16243: RscButton
		{
			idc = 16243;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.6 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [24] call Client_fnc_interactionAction;
		};
		class RscButton_16253: RscButton
		{
			idc = 16253;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.64 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [25] call Client_fnc_interactionAction;
		};
		class RscButton_16263: RscButton
		{
			idc = 16263;
			x = 0.75125 * safezoneW + safezoneX;
			y = 0.68 * safezoneH + safezoneY;
			w = 0.084583 * safezoneW;
			h = 0.0329871 * safezoneH; font = "PuristaMedium";
			colorBackground[] = {0.5,0,0,0.9};
			action = [26] call Client_fnc_interactionAction;
		};
	};
};