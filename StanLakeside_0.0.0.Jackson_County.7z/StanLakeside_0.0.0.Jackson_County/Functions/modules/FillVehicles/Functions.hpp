class FillVehicles_Module  {
	tag = "ClientModules_FillVehicles";
	class FillVehiclesInit
	{
		file = "Functions\modules\FillVehicles";
		class initFillVehicles {};
	};
	class FillVehicles
	{
		file = "Functions\modules\FillVehicles\Functions";
		class fillVehicle {};
		class setFill {};
	};
};
