class slideout {
        name = "slideout";
        sound[] = {
            "@cg_mission_files\sounds\slideout.ogg",
            1,
            1
        };
        titles[] = {};
    };