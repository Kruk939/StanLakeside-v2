
	class RSC_DOMSG7
	{    
		idd = -1;
		fadein=1;
	  	fadeout=1;
		duration = 4;
		name="RSC_DOMSG7";
		onLoad="uiNamespace setVariable ['RSC_DOMSG7',_this select 0]";
		objects[]={};
		class controls
		{
			class cg_popup_text_basic7
			{
				type=13;
				style=0x0c+0x02;
				idc=13377;
				x = 0.01 * safezoneW + safezoneX;
				y = 0.200 * safezoneH + safezoneY;
				w = 0.45;
				h = 0.11;
				sizeEx=0.035;
				size=0.035;
				font="PuristaMedium";
				colorBackground[]={0.05,0.05,0.1,0.7};
				colorText[] = { 1 , 1 , 1 , 0.95 };
				shadow=0;
				text="";
			};
		};	
	};

	class RSC_DOMSG6
	{    
		idd = -1;
		fadein=1;
	  	fadeout=1;
		duration = 7;
		name="RSC_DOMSG6";
		onLoad="uiNamespace setVariable ['RSC_DOMSG6',_this select 0]";
		objects[]={};
		class controls
		{
			class cg_popup_text_basic6
			{
				type=CT_STRUCTURED_TEXT;
				idc=13376;
				style=ST_LEFT;
				x = 0.01 * safezoneW + safezoneX;
				y = 0.350 * safezoneH + safezoneY;
				w = 0.45;
				h = 0.11;
				valign = "left";
				sizeEx=0.035;
				size=0.035;
				font="PuristaMedium";
				colorBackground[]={0.05,0.05,0.1,0.7};
				colorText[] = { 1 , 1 , 1 , 0.95 };
				shadow=0;
				text="";
			};

		};	
	};

	class RSC_DOMSG5
	{    
		idd = -1;
		fadein=1;
	  	fadeout=1;
		duration = 7;
		name="RSC_DOMSG5";
		onLoad="uiNamespace setVariable ['RSC_DOMSG5',_this select 0]";
		objects[]={};
		class controls
		{
			class cg_popup_text_basic5
			{
				type=CT_STRUCTURED_TEXT;
				idc=13375;
				style=ST_LEFT;
				x = 0.01 * safezoneW + safezoneX;
				y = 0.420 * safezoneH + safezoneY;
				w = 0.45;
				h = 0.11;
				valign = "left";
				sizeEx=0.035;
				size=0.035;
				font="PuristaMedium";
				colorBackground[]={0.05,0.05,0.1,0.7};
				colorText[] = { 1 , 1 , 1 , 0.95 };
				shadow=0;
				text="";
			};

		};	
	};


	class RSC_DOMSG4
	{    
		idd = -1;
		fadein=1;
	  	fadeout=1;
		duration = 7;
		name="RSC_DOMSG4";
		onLoad="uiNamespace setVariable ['RSC_DOMSG4',_this select 0]";
		objects[]={};
		class controls
		{
			class cg_popup_text_basic4
			{
				type=CT_STRUCTURED_TEXT;
				idc=13374;
				style=ST_LEFT;
				x = 0.01 * safezoneW + safezoneX;
				y = 0.490 * safezoneH + safezoneY;
				w = 0.45;
				h = 0.11;
				valign = "left";
				sizeEx=0.035;
				size=0.035;
				font="PuristaMedium";
				colorBackground[]={0.05,0.05,0.1,0.7};
				colorText[] = { 1 , 1 , 1 , 0.95 };
				shadow=0;
				text="";
			};

		};	
	};

	class RSC_DOMSG3
	{    
		idd = -1;
		fadein=1;
	  	fadeout=1;
		duration = 7;
		name="RSC_DOMSG3";
		onLoad="uiNamespace setVariable ['RSC_DOMSG3',_this select 0]";
		objects[]={};
		class controls
		{

			class cg_popup_text_basic3
			{
				type=CT_STRUCTURED_TEXT;
				idc=13373;
				style=ST_LEFT;
				x = 0.01 * safezoneW + safezoneX;
				y = 0.560 * safezoneH + safezoneY;
				w = 0.45;
				h = 0.11;
				valign = "left";
				sizeEx=0.035;
				size=0.035;
				font="PuristaMedium";
				colorBackground[]={0.05,0.05,0.1,0.7};
				colorText[] = { 1 , 1 , 1 , 0.95 };
				shadow=0;
				text="";
			};

		};	
	};

	class RSC_DOMSG2
	{    
		idd = -1;
		fadein=1;
	  	fadeout=1;
		duration = 7;
		name="RSC_DOMSG2";
		onLoad="uiNamespace setVariable ['RSC_DOMSG2',_this select 0]";
		objects[]={};
		class controls
		{
			class cg_popup_text_basic2
			{
				type=CT_STRUCTURED_TEXT;
				idc=13372;
				style=ST_LEFT;
				x = 0.01 * safezoneW + safezoneX;
				y = 0.630 * safezoneH + safezoneY;
				w = 0.45;
				h = 0.11;
				valign = "left";
				sizeEx=0.035;
				size=0.035;
				font="PuristaMedium";
				colorBackground[]={0.05,0.05,0.1,0.7};
				colorText[] = { 1 , 1 , 1 , 0.95 };
				shadow=0;
				text="";
			};
		};	
	};

	class RSC_DOMSG1
	{    
		idd = -1;
		fadein=1;
	  	fadeout=1;
		duration = 7;
		name="RSC_DOMSG1";
		onLoad="uiNamespace setVariable ['RSC_DOMSG1',_this select 0]";
		objects[]={};
		class controls
		{
			class cg_popup_text_basic1
			{
				type=CT_STRUCTURED_TEXT;
				idc=13371;
				style=ST_LEFT;
				x = 0.01 * safezoneW + safezoneX;
				y = 0.700 * safezoneH + safezoneY;
				w = 0.45;
				h = 0.11;
				valign = "left";
				sizeEx=0.035;
				size=0.035;
				font="PuristaMedium";
				colorBackground[]={0.05,0.05,0.1,0.7};
				colorText[] = { 1 , 1 , 1 , 0.95 };
				shadow=0;
				text="";
			};
		};	
	};