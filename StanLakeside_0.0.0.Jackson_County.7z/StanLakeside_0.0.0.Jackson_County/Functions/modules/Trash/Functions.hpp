class Trash_Module  {
	tag = "ClientModules_Trash";
	class TrashInit
	{
		file = "Functions\modules\Trash";
		class initTrash {};
	};
	class Trash
	{
		file = "Functions\modules\Trash\Functions";
		class searchTrash {}; // tu dodajemy funkcje np. nazwafunkcji.sqf
	//	class  {};
	};
};
