class VehicleInits_Module {
	tag = "ClientModules_VehicleInits";

	class VehicleInitsInit
	{
		file = "Functions\modules\VehicleInits";
		class initVehicleInits {};
	};
	class VehicleInits
	{
		file = "Functions\modules\VehicleInits\Functions";
		class IvoryInit {};
		class JonzieInit {};
		class numberPlate {};
	};
};