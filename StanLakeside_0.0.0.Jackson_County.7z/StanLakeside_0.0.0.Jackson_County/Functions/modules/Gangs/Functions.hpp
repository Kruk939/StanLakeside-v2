class Gangs_Module  {
	tag = "ClientModules_Gangs";
	class GangsInit
	{
		file = "Functions\modules\Gangs";
		class initGangs {};
	};
	class Gangs
	{
		file = "Functions\modules\Gangs\Functions";
		class checkGang {}; // tu dodajemy funkcje np. nazwafunkcji.sqf
	//	class  {};
	};
};
