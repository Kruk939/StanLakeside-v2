class FadeSound_Module {
	tag = "ClientModules_FadeSound";
	class FadeSoundInit
	{
		file = "Functions\modules\fadeSound";
		class initFadeSound {};
	};
	class FadeSound
	{
		file = "Functions\modules\fadeSound\Functions";
			class handleKeys {};
	};
};