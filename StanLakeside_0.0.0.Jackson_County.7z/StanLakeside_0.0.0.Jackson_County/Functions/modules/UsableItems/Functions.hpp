class UsableItems_Module {
	tag = "ClientModules_UsableItems";
	
	class UsableItemsInit
	{
		file = "Functions\modules\UsableItems";
		class initUsableItems {};
	};
	class UsableItems
	{
		file = "Functions\modules\UsableItems\Functions";
        class itemNOS {};
        class itemSpeedBomb {};
        class itemGoPro {};
	};
};