class mav_ttm_fnc_loadFromDatabase {
    allowedTargets = 2;
};
class mav_ttm_fnc_updateDatabaseEntry {
    allowedTargets = 2;
};