class Example {
    expToAdd = 100;
	message = "Customizable Message";
};