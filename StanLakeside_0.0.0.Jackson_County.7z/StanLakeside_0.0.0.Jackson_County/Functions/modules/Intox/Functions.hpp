class Intox_Module {
	tag = "ClientModules_Intox";
	
	class IntoxInit
	{
		file = "Functions\modules\Intox";
    	class initIntox {};
	};
	class Intox
	{
		file = "Functions\modules\Intox\Functions";
		class intoxTestReturn {};
		class testIntoxClient {};
		class testIntox {};
    	class intox {};
	};
};