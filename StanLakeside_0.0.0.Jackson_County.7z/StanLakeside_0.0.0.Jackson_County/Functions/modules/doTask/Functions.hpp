class DoTask_Module {
	tag = "ClientModules_doTask";

	class DoTaskInit
	{
		file = "Functions\modules\doTask";
		class initDoTaskSystem {};
	};
	class DoTask
	{
		file = "Functions\modules\doTask\Functions";
		class doTask {};
	};
};