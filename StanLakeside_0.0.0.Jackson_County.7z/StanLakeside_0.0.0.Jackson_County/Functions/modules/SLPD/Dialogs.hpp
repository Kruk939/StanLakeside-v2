#include "Dialogs\kruk_slpd_computer.hpp"
#include "Dialogs\kruk_slpd_ticket.hpp"