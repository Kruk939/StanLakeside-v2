class PlayerNames_Module {
	tag = "ClientModules_PlayerNames";

	class PlayerNamesInit
	{
		file = "Functions\modules\PlayerNames";
		class initPlayerNames {};
	};
	class PlayerNames
	{
		file = "Functions\modules\PlayerNames\Functions";
		class nametags {};
	};
};