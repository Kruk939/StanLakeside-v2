class Housing_Module {
	tag = "ClientModules_Housing";

	class HousingInit
	{
		file = "Functions\modules\Housing";
		class initHousing {};
	};
	class Housing
	{
		file = "Functions\modules\Housing\Functions";
		//class xxx {};
	};
};