class phone
{
	idd = 1101;
	class controls 
	{
////////////////////////////////////////////////////////
// Wallpaper
////////////////////////////////////////////////////////
		class RscPicture_1200: RscPicture
		{
			idc = 1201;
			text = "\SL_Client\Textures\Dialogs\Phone\Wallpapers\1.paa";
			x = 5 * GUI_GRID_W + GUI_GRID_X;
			y = -1 * GUI_GRID_H + GUI_GRID_Y;
			w = 28.5 * GUI_GRID_W;
			h = 22 * GUI_GRID_H;
		};
////////////////////////////////////////////////////////
// Phone frame
////////////////////////////////////////////////////////
		class RscPicture_1201: RscPicture
		{
			idc = 1200;
			text = "\SL_Client\Textures\Dialogs\Phone\PhoneFrame\bg1.paa";
			x = 5.5 * GUI_GRID_W + GUI_GRID_X;
			y = -1 * GUI_GRID_H + GUI_GRID_Y;
			w = 27.5 * GUI_GRID_W;
			h = 22 * GUI_GRID_H;
		};
////////////////////////////////////////////////////////
// Home picture
////////////////////////////////////////////////////////
		class RscPicture_1202: RscPicture
		{
			idc = 1202;
			text = "SL_Client\Textures\Dialogs\Phone\Icons\home.paa";
			x = 18.5 * GUI_GRID_W + GUI_GRID_X;
			y = 17 * GUI_GRID_H + GUI_GRID_Y;
			w = 2 * GUI_GRID_W;
			h = 1.5 * GUI_GRID_H;
		};
////////////////////////////////////////////////////////
// Contacts picture
////////////////////////////////////////////////////////
		class RscPicture_1203: RscPicture
		{
			idc = 1203;
			text = "SL_Client\Textures\Dialogs\Phone\Icons\contacts.paa";
			x = 14 * GUI_GRID_W + GUI_GRID_X;
			y = 3.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 2.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
////////////////////////////////////////////////////////
// Sync picture
////////////////////////////////////////////////////////
		class RscPicture_1204: RscPicture
		{
			idc = 1204;
			text = "SL_Client\Textures\Dialogs\Phone\Icons\security.paa";
			x = 22 * GUI_GRID_W + GUI_GRID_X;
			y = 8.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 2.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
////////////////////////////////////////////////////////
// Person picture
////////////////////////////////////////////////////////
		class RscPicture_1205: RscPicture
		{
			idc = 1205;
			text = "SL_Client\Textures\Dialogs\Phone\Icons\person.paa";
			x = 22 * GUI_GRID_W + GUI_GRID_X;
			y = 3.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 2.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
////////////////////////////////////////////////////////
// message picture
////////////////////////////////////////////////////////
		class RscPicture_1206: RscPicture
		{
			idc = 1206;
			text = "SL_Client\Textures\Dialogs\Phone\Icons\chat.paa";
			x = 18 * GUI_GRID_W + GUI_GRID_X;
			y = 3.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 2.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
////////////////////////////////////////////////////////
// Wallet picture
////////////////////////////////////////////////////////
		class RscPicture_1207: RscPicture
		{
			idc = 1207;
			text = "SL_Client\Textures\Dialogs\Phone\Icons\wallet.paa";
			x = 14 * GUI_GRID_W + GUI_GRID_X;
			y = 6 * GUI_GRID_H + GUI_GRID_Y;
			w = 2.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
////////////////////////////////////////////////////////
// keys picture
////////////////////////////////////////////////////////
		class RscPicture_1208: RscPicture
		{
			idc = 1208;
			text = "SL_Client\Textures\Dialogs\Phone\Icons\key.paa";
			x = 18 * GUI_GRID_W + GUI_GRID_X;
			y = 6 * GUI_GRID_H + GUI_GRID_Y;
			w = 2.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
////////////////////////////////////////////////////////
// volume more
////////////////////////////////////////////////////////
		class RscPicture_1213: RscPicture
		{
			idc = 1213;
			text = "SL_Client\Textures\Dialogs\Phone\Icons\volume2.paa";
			x = 14 * GUI_GRID_W + GUI_GRID_X;
			y = 8.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 2.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
////////////////////////////////////////////////////////
// volume min
////////////////////////////////////////////////////////
		class RscPicture_1209: RscPicture
		{
			idc = 1209;
			text = "SL_Client\Textures\Dialogs\Phone\Icons\volume1.paa";
			x = 18 * GUI_GRID_W + GUI_GRID_X;
			y = 8.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 2.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
////////////////////////////////////////////////////////
// phone green
////////////////////////////////////////////////////////
		class RscPicture_1211: RscPicture
		{
			idc = 1211;
			text = "SL_Client\Textures\Dialogs\Phone\Icons\phonegreen.paa";
			x = 14 * GUI_GRID_W + GUI_GRID_X;
			y = 14.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 2.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
////////////////////////////////////////////////////////
// phone red
////////////////////////////////////////////////////////
		class RscPicture_1212: RscPicture
		{
			idc = 1212;
			text = "SL_Client\Textures\Dialogs\Phone\Icons\phonered.paa";
			x = 18 * GUI_GRID_W + GUI_GRID_X;
			y = 14.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 2.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
////////////////////////////////////////////////////////
// volume mute
////////////////////////////////////////////////////////
		class RscPicture_1210: RscPicture
		{
			idc = 1210;
			text = "SL_Client\Textures\Dialogs\Phone\Icons\volumemute.paa";
			x = 22 * GUI_GRID_W + GUI_GRID_X;
			y = 14.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 2.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
		class RscButton_1600: RscButtonInv
		{
			idc = 1600;
			//text = "Contacts"; //--- ToDo: Localize;
			tooltip = "Contacts"; //--- ToDo: Localize;
			action = "[] call ClientModules_Phone_fnc_loadContacts;";
			x = 14 * GUI_GRID_W + GUI_GRID_X;
			y = 3.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 2.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
		class RscButton_1601: RscButtonInv
		{
			idc = 1601;
			//text = "Messages"; //--- ToDo: Localize;
			tooltip = "Messages"; //--- ToDo: Localize;
			action = "[] call ClientModules_Phone_fnc_loadMessages;";
			x = 18 * GUI_GRID_W + GUI_GRID_X;
			y = 3.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 2.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
		class RscButton_1602: RscButtonInv
		{
			idc = 1602;
			//text = "Person"; //--- ToDo: Localize;
			tooltip = "Player info's"; //--- ToDo: Localize;
			action = "[] call ClientModules_Phone_fnc_loadPlayerInfo;";
			x = 22 * GUI_GRID_W + GUI_GRID_X;
			y = 3.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 2.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
		class RscButton_1604: RscButtonInv
		{
			idc = 1604;
			//text = "Keys"; //--- ToDo: Localize;
			tooltip = "Keys"; //--- ToDo: Localize;
			action = "[] call ClientModules_Phone_fnc_loadKeys;";
			x = 18 * GUI_GRID_W + GUI_GRID_X;
			y = 6 * GUI_GRID_H + GUI_GRID_Y;
			w = 2.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
		class RscButton_1605: RscButtonInv
		{
			idc = 1605;
			//text = "Wallet"; //--- ToDo: Localize;
			tooltip = "Wallet"; //--- ToDo: Localize;
			action = "[] call ClientModules_Phone_fnc_loadWallet;";
			x = 14 * GUI_GRID_W + GUI_GRID_X;
			y = 6 * GUI_GRID_H + GUI_GRID_Y;
			w = 2.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
		class RscButton_1606: RscButtonInv
		{
			idc = 1606;
			//text = "Sync"; //--- ToDo: Localize;
			tooltip = "Synchronize me"; //--- ToDo: Localize;
			x = 22 * GUI_GRID_W + GUI_GRID_X;
			y = 8.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 2.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
		class RscButton_1607: RscButtonInv
		{
			idc = 1607;
			//text = "Vol min"; //--- ToDo: Localize;
			tooltip = "Volume -"; //--- ToDo: Localize;
			action = "[] call ClientModules_Phone_fnc_lessVolume;";
			x = 18 * GUI_GRID_W + GUI_GRID_X;
			y = 8.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 2.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
		class RscButton_1608: RscButtonInv
		{
			idc = 1608;
			//text = "Vol more"; //--- ToDo: Localize;
			tooltip = "Volume +"; //--- ToDo: Localize;
			action = "[] call ClientModules_Phone_fnc_moreVolume;";
			x = 14 * GUI_GRID_W + GUI_GRID_X;
			y = 8.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 2.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
		class RscButton_1609: RscButtonInv
		{
			idc = 1609;
			//text = "Phone green"; //--- ToDo: Localize;
			tooltip = "Answer call"; //--- ToDo: Localize;
			action = "[] call ClientModules_Phone_fnc_answerCall;";
			x = 14 * GUI_GRID_W + GUI_GRID_X;
			y = 14.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 2.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
		class RscButton_1610: RscButtonInv
		{
			idc = 1610;
			//text = "Phone red"; //--- ToDo: Localize;
			tooltip = "End call"; //--- ToDo: Localize;
			action = "[] call ClientModules_Phone_fnc_endCall;";
			x = 18 * GUI_GRID_W + GUI_GRID_X;
			y = 14.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 2.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
		class RscButton_1611: RscButtonInv
		{
			idc = 1611;
			//text = "Vol mute"; //--- ToDo: Localize;
			tooltip = "Turn off calls"; //--- ToDo: Localize;
			action = "[] call ClientModules_Phone_fnc_disablePhone;";
			x = 22 * GUI_GRID_W + GUI_GRID_X;
			y = 14.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 2.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
		class RscButton_1612: RscButtonInv
		{
			idc = 1612;
			//text = "Home"; //--- ToDo: Localize;
			tooltip = "Home button"; //--- ToDo: Localize;
			action = "[] call ClientModules_Phone_fnc_openPhone;";
			x = 18.5 * GUI_GRID_W + GUI_GRID_X;
			y = 17 * GUI_GRID_H + GUI_GRID_Y;
			w = 2 * GUI_GRID_W;
			h = 1.5 * GUI_GRID_H;
		};


	};
};