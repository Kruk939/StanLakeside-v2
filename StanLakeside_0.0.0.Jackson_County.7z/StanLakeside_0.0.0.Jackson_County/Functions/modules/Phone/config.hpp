class RPF_phoneModule {
	emergencyNumber = "911";
};