#include "Dialogs\AdminPanel.hpp"
#include "Dialogs\messageFromAdmin.hpp"