class Example_Module {
	tag = "ClientModules_Example";

	class ExampleInit
	{
		file = "Functions\modules\#Example";
		class initExample {};
		class initExampleMenu {};
	};
	class Example
	{
		file = "Functions\modules\#Example\Functions";
		class hintExample {};

	};
};