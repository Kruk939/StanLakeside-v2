class Mafia_Module {
	tag = "ClientModules_Mafia";
	
	class MafiaInit
	{
		file = "Functions\modules\Mafia";
		class initMafia {};
	};
	class Mafia
	{
		file = "Functions\modules\Mafia\Functions";
		class buyAssasinInv {};
	};
};