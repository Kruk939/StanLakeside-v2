/*
	Author: Maverick Applications
	Desc: Altis Life Shipwreck
*/

//Do not touch below
class Maverick_Shipwrecks {

	tag = "mav_Shipwrecks";

	class functions {

		file = "Functions\modules\Shipwrecks\scripts";
        class initShipwreck {headerType = -1;};
        class loadShipwreck {postInit = 1; headerType = -1;};
	};

};